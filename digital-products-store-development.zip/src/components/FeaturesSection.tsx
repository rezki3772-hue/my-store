import { Shield, Zap, Download, HeadphonesIcon, RefreshCw, Lock } from 'lucide-react';

const features = [
  {
    icon: <Zap className="w-6 h-6" />,
    title: 'تحميل فوري',
    description: 'احصل على منتجاتك فور إتمام عملية الدفع مباشرةً',
    color: 'from-yellow-500 to-orange-500',
    bg: 'bg-yellow-500/10',
  },
  {
    icon: <Shield className="w-6 h-6" />,
    title: 'ضمان استرداد',
    description: 'ضمان استرداد كامل خلال 30 يوم بدون أي أسئلة',
    color: 'from-green-500 to-emerald-500',
    bg: 'bg-green-500/10',
  },
  {
    icon: <Lock className="w-6 h-6" />,
    title: 'دفع آمن 100%',
    description: 'تشفير SSL كامل وحماية بيانات متقدمة في كل عملية',
    color: 'from-blue-500 to-cyan-500',
    bg: 'bg-blue-500/10',
  },
  {
    icon: <HeadphonesIcon className="w-6 h-6" />,
    title: 'دعم 24/7',
    description: 'فريق دعم محترف متاح على مدار الساعة لمساعدتك',
    color: 'from-purple-500 to-violet-500',
    bg: 'bg-purple-500/10',
  },
  {
    icon: <RefreshCw className="w-6 h-6" />,
    title: 'تحديثات مجانية',
    description: 'استمتع بجميع التحديثات المستقبلية مجاناً مدى الحياة',
    color: 'from-pink-500 to-rose-500',
    bg: 'bg-pink-500/10',
  },
  {
    icon: <Download className="w-6 h-6" />,
    title: 'تنزيلات غير محدودة',
    description: 'حمّل منتجاتك على أي جهاز وبأي عدد من المرات',
    color: 'from-indigo-500 to-blue-500',
    bg: 'bg-indigo-500/10',
  },
];

export default function FeaturesSection() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 glass-card rounded-full px-4 py-2 mb-4 border border-indigo-500/30">
            <span className="text-indigo-400 text-sm font-semibold">⭐ لماذا نحن؟</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white mb-4">
            تجربة تسوق{' '}
            <span className="gradient-text">لا مثيل لها</span>
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto">
            نقدم لك أفضل تجربة تسوق رقمي مع مميزات حصرية تجعل كل عملية شراء آمنة وممتعة
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="glass-card rounded-2xl p-6 card-hover border border-white/10 hover:border-violet-500/30 group fade-in-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className={`w-14 h-14 ${feature.bg} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                <div className={`bg-gradient-to-br ${feature.color} bg-clip-text text-transparent`}>
                  {feature.icon}
                </div>
              </div>
              <h3 className="text-white font-bold text-lg mb-2">{feature.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
