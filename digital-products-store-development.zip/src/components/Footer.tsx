import { Zap, Mail, Phone, MapPin, Globe, AtSign, MessageCircle, Video } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-white/10 py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center pulse-glow">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <div>
                <span className="text-white font-bold text-xl">Digital</span>
                <span className="gradient-text font-bold text-xl">Hub</span>
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed mb-6">
              متجرك الأول للمنتجات الرقمية الاحترافية. نوفر أفضل القوالب والكورسات والأدوات لمساعدتك في النجاح.
            </p>
            {/* Social Links */}
            <div className="flex items-center gap-3">
              {[
                { icon: <Globe className="w-4 h-4" />, label: 'موقع' },
                { icon: <AtSign className="w-4 h-4" />, label: 'تويتر' },
                { icon: <MessageCircle className="w-4 h-4" />, label: 'انستغرام' },
                { icon: <Video className="w-4 h-4" />, label: 'يوتيوب' },
              ].map((social, i) => (
                <a
                  key={i}
                  href="#"
                  title={social.label}
                  className="w-9 h-9 glass-card rounded-xl flex items-center justify-center text-gray-400 hover:text-white hover:bg-violet-600 transition-all duration-300 border border-white/10"
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-bold mb-5">روابط سريعة</h3>
            <ul className="space-y-3">
              {['الرئيسية', 'المنتجات', 'الكورسات', 'القوالب', 'الباقات', 'المدونة'].map((link) => (
                <li key={link}>
                  <a href="#" className="text-gray-400 hover:text-violet-400 transition-colors text-sm flex items-center gap-2 group">
                    <span className="w-1.5 h-1.5 bg-violet-500 rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="text-white font-bold mb-5">التصنيفات</h3>
            <ul className="space-y-3">
              {[
                { name: 'قوالب', emoji: '🎨' },
                { name: 'كورسات', emoji: '📚' },
                { name: 'برامج', emoji: '💻' },
                { name: 'كتب رقمية', emoji: '📖' },
                { name: 'جرافيك', emoji: '🖼️' },
                { name: 'موسيقى', emoji: '🎵' },
              ].map((cat) => (
                <li key={cat.name}>
                  <a href="#" className="text-gray-400 hover:text-violet-400 transition-colors text-sm flex items-center gap-2">
                    <span>{cat.emoji}</span>
                    {cat.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white font-bold mb-5">تواصل معنا</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <Mail className="w-4 h-4 text-violet-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-gray-400 text-xs mb-0.5">البريد الإلكتروني</p>
                  <a href="mailto:support@digitalhub.com" className="text-gray-300 hover:text-white text-sm transition-colors">
                    support@digitalhub.com
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Phone className="w-4 h-4 text-violet-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-gray-400 text-xs mb-0.5">الهاتف</p>
                  <a href="tel:+966500000000" className="text-gray-300 hover:text-white text-sm transition-colors">
                    +966 50 000 0000
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-violet-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-gray-400 text-xs mb-0.5">العنوان</p>
                  <p className="text-gray-300 text-sm">الرياض، المملكة العربية السعودية</p>
                </div>
              </li>
            </ul>

            {/* Payment Methods */}
            <div className="mt-6">
              <p className="text-gray-400 text-xs mb-3">طرق الدفع المقبولة</p>
              <div className="flex flex-wrap gap-2">
                {['💳 Visa', '💳 Mastercard', '🏦 PayPal', '📱 Apple Pay'].map((method) => (
                  <span key={method} className="glass-card text-gray-400 text-xs px-2 py-1 rounded-lg border border-white/10">
                    {method}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-gray-500 text-sm">
            © 2025 DigitalHub. جميع الحقوق محفوظة. صُنع بـ ❤️ للعالم العربي
          </p>
          <div className="flex items-center gap-6">
            {['سياسة الخصوصية', 'شروط الاستخدام', 'سياسة الاسترداد'].map((link) => (
              <a key={link} href="#" className="text-gray-500 hover:text-gray-300 text-xs transition-colors">
                {link}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
