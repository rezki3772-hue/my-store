import { useState, useMemo } from 'react';
import { SlidersHorizontal, Grid3X3, List, ArrowUpDown } from 'lucide-react';
import { products, categories, Product } from '../data/products';
import ProductCard from './ProductCard';

interface ProductsSectionProps {
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
  searchQuery: string;
}

export default function ProductsSection({ onAddToCart, onQuickView, searchQuery }: ProductsSectionProps) {
  const [activeCategory, setActiveCategory] = useState('all');
  const [sortBy, setSortBy] = useState('default');
  const [priceRange] = useState<[number, number]>([0, 500]);

  const filteredProducts = useMemo(() => {
    let filtered = products;

    // Category filter
    if (activeCategory !== 'all') {
      filtered = filtered.filter((p) => p.category === activeCategory);
    }

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(
        (p) =>
          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Price filter
    filtered = filtered.filter(
      (p) => p.price >= priceRange[0] && p.price <= priceRange[1]
    );

    // Sort
    switch (sortBy) {
      case 'price-asc':
        filtered = [...filtered].sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        filtered = [...filtered].sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        filtered = [...filtered].sort((a, b) => b.rating - a.rating);
        break;
      case 'downloads':
        filtered = [...filtered].sort((a, b) => b.downloads - a.downloads);
        break;
      default:
        break;
    }

    return filtered;
  }, [activeCategory, searchQuery, sortBy, priceRange]);

  return (
    <section id="products" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Section Header */}
      <div className="text-center mb-12">
        <div className="inline-flex items-center gap-2 glass-card rounded-full px-4 py-2 mb-4 border border-violet-500/30">
          <span className="text-violet-400 text-sm font-semibold">🛍️ المتجر</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-black text-white mb-4">
          استكشف{' '}
          <span className="gradient-text">منتجاتنا المميزة</span>
        </h2>
        <p className="text-gray-400 max-w-xl mx-auto">
          اختر من بين مئات المنتجات الرقمية الاحترافية المصممة بعناية لتلبية احتياجاتك
        </p>
      </div>

      {/* Categories */}
      <div className="flex flex-wrap justify-center gap-3 mb-8">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-300 ${
              activeCategory === cat.id
                ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-lg shadow-violet-500/30 scale-105'
                : 'glass-card text-gray-400 hover:text-white hover:bg-white/10 border border-white/10'
            }`}
          >
            <span>{cat.icon}</span>
            {cat.name}
          </button>
        ))}
      </div>

      {/* Filters Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-8 glass-card rounded-2xl p-4 border border-white/10">
        <div className="flex items-center gap-3">
          <SlidersHorizontal className="w-4 h-4 text-violet-400" />
          <span className="text-gray-400 text-sm">
            عرض <span className="text-white font-bold">{filteredProducts.length}</span> منتج
          </span>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          {/* Sort */}
          <div className="flex items-center gap-2">
            <ArrowUpDown className="w-4 h-4 text-gray-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="bg-white/10 text-gray-300 text-sm rounded-lg px-3 py-1.5 outline-none border border-white/10 hover:border-violet-400/50 transition-colors cursor-pointer"
            >
              <option value="default" className="bg-gray-900">الافتراضي</option>
              <option value="price-asc" className="bg-gray-900">السعر: الأقل أولاً</option>
              <option value="price-desc" className="bg-gray-900">السعر: الأعلى أولاً</option>
              <option value="rating" className="bg-gray-900">الأعلى تقييماً</option>
              <option value="downloads" className="bg-gray-900">الأكثر تحميلاً</option>
            </select>
          </div>

          {/* View Mode Icons */}
          <div className="flex items-center gap-1 bg-white/10 rounded-lg p-1">
            <button className="p-1.5 rounded-md bg-violet-600 text-white">
              <Grid3X3 className="w-3.5 h-3.5" />
            </button>
            <button className="p-1.5 rounded-md text-gray-400 hover:text-white transition-colors">
              <List className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Products Grid */}
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product, index) => (
            <div
              key={product.id}
              className="fade-in-up"
              style={{ animationDelay: `${index * 0.05}s` }}
            >
              <ProductCard
                product={product}
                onAddToCart={onAddToCart}
                onQuickView={onQuickView}
              />
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-20">
          <div className="text-6xl mb-4">🔍</div>
          <h3 className="text-white text-xl font-bold mb-2">لا توجد نتائج</h3>
          <p className="text-gray-400">جرب البحث بكلمات مختلفة أو غيّر الفئة</p>
        </div>
      )}
    </section>
  );
}
