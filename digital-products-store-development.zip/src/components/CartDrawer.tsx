import { X, ShoppingCart, Trash2, Plus, Minus, Download, CreditCard, Tag } from 'lucide-react';
import { CartItem } from '../types';
import { useState } from 'react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (id: number, quantity: number) => void;
  onRemoveItem: (id: number) => void;
  onClearCart: () => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}: CartDrawerProps) {
  const [coupon, setCoupon] = useState('');
  const [couponApplied, setCouponApplied] = useState(false);
  const [checkoutDone, setCheckoutDone] = useState(false);

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discount = couponApplied ? Math.round(subtotal * 0.15) : 0;
  const total = subtotal - discount;

  const handleCoupon = () => {
    if (coupon.toUpperCase() === 'DIGITAL15') {
      setCouponApplied(true);
    }
  };

  const handleCheckout = () => {
    setCheckoutDone(true);
    setTimeout(() => {
      setCheckoutDone(false);
      onClearCart();
      onClose();
    }, 2500);
  };

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
          onClick={onClose}
        />
      )}

      {/* Drawer */}
      <div
        className={`fixed top-0 left-0 h-full w-full sm:w-[420px] z-50 flex flex-col transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
        style={{ background: 'linear-gradient(to bottom, #1a0f2e, #0f0a1e)' }}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-violet-600 rounded-xl flex items-center justify-center">
              <ShoppingCart className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-white font-bold text-lg">سلة المشتريات</h2>
              <p className="text-gray-400 text-xs">{cartItems.length} منتج</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {cartItems.length > 0 && (
              <button
                onClick={onClearCart}
                className="text-gray-400 hover:text-red-400 text-xs transition-colors px-2 py-1 rounded-lg hover:bg-red-500/10"
              >
                مسح الكل
              </button>
            )}
            <button
              onClick={onClose}
              className="w-8 h-8 flex items-center justify-center rounded-xl bg-white/10 hover:bg-white/20 text-gray-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Success State */}
        {checkoutDone && (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <div className="text-6xl mb-4 float-animation">✅</div>
            <h3 className="text-white font-bold text-2xl mb-2">تم الشراء بنجاح!</h3>
            <p className="text-gray-400">ستصلك رسالة تأكيد على بريدك الإلكتروني</p>
            <div className="mt-6 flex items-center gap-2 text-violet-400 text-sm">
              <Download className="w-4 h-4" />
              جاري تجهيز ملفات التحميل...
            </div>
          </div>
        )}

        {/* Empty State */}
        {!checkoutDone && cartItems.length === 0 && (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <div className="text-6xl mb-4 float-animation">🛒</div>
            <h3 className="text-white font-bold text-xl mb-2">سلتك فارغة!</h3>
            <p className="text-gray-400 text-sm">أضف بعض المنتجات الرائعة إلى سلتك</p>
            <button
              onClick={onClose}
              className="mt-6 bg-violet-600 hover:bg-violet-700 text-white px-6 py-3 rounded-xl text-sm font-bold transition-colors"
            >
              تصفح المنتجات
            </button>
          </div>
        )}

        {/* Items */}
        {!checkoutDone && cartItems.length > 0 && (
          <>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {cartItems.map((item) => (
                <div
                  key={item.id}
                  className="glass-card rounded-xl p-4 flex items-center gap-3 cart-slide-in"
                >
                  {/* Icon */}
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${item.color} flex items-center justify-center text-2xl flex-shrink-0`}>
                    {item.icon}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-semibold line-clamp-1">{item.name}</p>
                    <p className="text-violet-400 font-bold">${item.price}</p>
                  </div>

                  {/* Quantity & Remove */}
                  <div className="flex flex-col items-end gap-2">
                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="text-gray-500 hover:text-red-400 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                        className="w-6 h-6 rounded-lg bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-white text-sm font-bold w-5 text-center">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                        className="w-6 h-6 rounded-lg bg-violet-600 hover:bg-violet-700 text-white flex items-center justify-center transition-colors"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Coupon */}
            <div className="px-4 pb-3">
              <div className="flex gap-2">
                <div className="flex-1 flex items-center gap-2 bg-white/10 rounded-xl px-3 py-2.5 border border-white/10">
                  <Tag className="w-4 h-4 text-violet-400 flex-shrink-0" />
                  <input
                    type="text"
                    placeholder="كود الخصم (DIGITAL15)"
                    className="bg-transparent text-white text-sm placeholder-gray-500 outline-none flex-1"
                    value={coupon}
                    onChange={(e) => setCoupon(e.target.value)}
                    disabled={couponApplied}
                  />
                </div>
                <button
                  onClick={handleCoupon}
                  disabled={couponApplied}
                  className={`px-4 py-2.5 rounded-xl text-sm font-bold transition-colors ${
                    couponApplied
                      ? 'bg-green-500 text-white'
                      : 'bg-violet-600 hover:bg-violet-700 text-white'
                  }`}
                >
                  {couponApplied ? '✓' : 'تطبيق'}
                </button>
              </div>
              {couponApplied && (
                <p className="text-green-400 text-xs mt-1 text-right">✓ تم تطبيق خصم 15%</p>
              )}
            </div>

            {/* Summary */}
            <div className="border-t border-white/10 p-4 space-y-3">
              <div className="flex justify-between text-gray-400 text-sm">
                <span>المجموع الفرعي</span>
                <span className="text-white font-semibold">${subtotal}</span>
              </div>
              {couponApplied && (
                <div className="flex justify-between text-green-400 text-sm">
                  <span>الخصم (15%)</span>
                  <span>-${discount}</span>
                </div>
              )}
              <div className="flex justify-between text-gray-400 text-sm">
                <span>رسوم التوصيل</span>
                <span className="text-green-400">مجاني 🎉</span>
              </div>
              <div className="flex justify-between text-white font-black text-xl pt-2 border-t border-white/10">
                <span>الإجمالي</span>
                <span className="gradient-text">${total}</span>
              </div>

              <button
                onClick={handleCheckout}
                className="w-full bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white font-bold py-4 rounded-2xl transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-violet-500/30 flex items-center justify-center gap-2"
              >
                <CreditCard className="w-5 h-5" />
                إتمام الشراء — ${total}
              </button>
              <p className="text-center text-gray-500 text-xs">🔒 دفع آمن مشفر بالكامل</p>
            </div>
          </>
        )}
      </div>
    </>
  );
}
