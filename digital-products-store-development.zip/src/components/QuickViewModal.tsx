import { X, Star, Download, Shield, Zap, ShoppingCart, Check } from 'lucide-react';
import { Product } from '../data/products';
import { useState } from 'react';

interface QuickViewModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
}

export default function QuickViewModal({ product, onClose, onAddToCart }: QuickViewModalProps) {
  const [added, setAdded] = useState(false);

  if (!product) return null;

  const handleAdd = () => {
    onAddToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div
        className="relative w-full max-w-2xl glass-card rounded-3xl overflow-hidden fade-in-up border border-white/10"
        style={{ background: 'linear-gradient(135deg, #1a0f2e, #0f0a1e)' }}
      >
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-4 left-4 z-10 w-9 h-9 rounded-full bg-black/50 flex items-center justify-center text-gray-400 hover:text-white hover:bg-black/70 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex flex-col md:flex-row">
          {/* Left: Icon */}
          <div className={`relative md:w-64 h-48 md:h-auto bg-gradient-to-br ${product.color} flex items-center justify-center flex-shrink-0`}>
            <div className="absolute inset-0 shimmer" />
            <span className="text-8xl float-animation relative z-10">{product.icon}</span>
            {discount && (
              <div className="absolute top-4 right-4 bg-red-500 text-white text-sm font-bold px-3 py-1 rounded-xl">
                -{discount}%
              </div>
            )}
          </div>

          {/* Right: Details */}
          <div className="flex-1 p-6 flex flex-col">
            {product.badge && (
              <span className={`self-start mb-3 px-3 py-1 rounded-full text-xs font-bold ${
                product.badge === 'جديد' ? 'badge-new' : product.badge === 'الأكثر مبيعاً' ? 'badge-hot' : 'badge-sale'
              } text-white`}>
                {product.badge}
              </span>
            )}

            <h2 className="text-white font-black text-2xl mb-2">{product.name}</h2>
            <p className="text-gray-400 text-sm leading-relaxed mb-4">{product.description}</p>

            {/* Rating */}
            <div className="flex items-center gap-2 mb-4">
              <div className="flex items-center gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-4 h-4"
                    fill={i < Math.floor(product.rating) ? '#f59e0b' : 'none'}
                    stroke={i < Math.floor(product.rating) ? '#f59e0b' : '#6b7280'}
                  />
                ))}
              </div>
              <span className="text-yellow-400 font-bold">{product.rating}</span>
              <span className="text-gray-500 text-sm">({product.reviews.toLocaleString()} تقييم)</span>
            </div>

            {/* Features */}
            <div className="grid grid-cols-2 gap-2 mb-5">
              {product.features.map((feature, i) => (
                <div key={i} className="flex items-center gap-2 text-sm text-gray-300">
                  <Check className="w-4 h-4 text-green-400 flex-shrink-0" />
                  {feature}
                </div>
              ))}
            </div>

            {/* Trust Badges */}
            <div className="flex items-center gap-4 mb-5 flex-wrap">
              <div className="flex items-center gap-1.5 text-gray-400 text-xs">
                <Shield className="w-4 h-4 text-green-400" />
                ضمان استرداد 30 يوم
              </div>
              <div className="flex items-center gap-1.5 text-gray-400 text-xs">
                <Download className="w-4 h-4 text-blue-400" />
                {product.downloads.toLocaleString()} تحميل
              </div>
              <div className="flex items-center gap-1.5 text-gray-400 text-xs">
                <Zap className="w-4 h-4 text-yellow-400" />
                تحميل فوري
              </div>
            </div>

            {/* Price & CTA */}
            <div className="flex items-center gap-4 mt-auto">
              <div>
                <div className="text-3xl font-black text-white">${product.price}</div>
                {product.originalPrice && (
                  <div className="text-gray-500 text-sm line-through">${product.originalPrice}</div>
                )}
              </div>
              <button
                onClick={handleAdd}
                className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl font-bold text-white transition-all duration-300 ${
                  added
                    ? 'bg-green-500'
                    : 'bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 hover:scale-105 hover:shadow-lg hover:shadow-violet-500/30'
                }`}
              >
                {added ? (
                  <><Check className="w-5 h-5" /> تمت الإضافة!</>
                ) : (
                  <><ShoppingCart className="w-5 h-5" /> أضف إلى السلة</>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
