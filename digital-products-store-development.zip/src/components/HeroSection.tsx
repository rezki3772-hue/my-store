import { ArrowLeft, Star, Shield, Download, Users } from 'lucide-react';

interface HeroSectionProps {
  onExplore: () => void;
}

export default function HeroSection({ onExplore }: HeroSectionProps) {
  const stats = [
    { icon: <Download className="w-4 h-4" />, value: '50K+', label: 'تحميل' },
    { icon: <Users className="w-4 h-4" />, value: '12K+', label: 'عميل' },
    { icon: <Star className="w-4 h-4" />, value: '4.9', label: 'تقييم' },
    { icon: <Shield className="w-4 h-4" />, value: '100%', label: 'ضمان' },
  ];

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: 'url(/images/hero-bg.jpg)' }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0618]/80 via-[#0a0618]/60 to-[#0a0618]" />

      {/* Animated Orbs */}
      <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-violet-600/20 rounded-full blur-3xl float-animation" />
      <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-indigo-600/20 rounded-full blur-3xl float-animation" style={{ animationDelay: '1.5s' }} />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-cyan-600/10 rounded-full blur-3xl float-animation" style={{ animationDelay: '0.75s' }} />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 glass-card rounded-full px-4 py-2 mb-8 fade-in-up">
          <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
          <span className="text-gray-300 text-sm">🎉 خصم 50% على جميع الكورسات هذا الأسبوع!</span>
        </div>

        {/* Main Heading */}
        <h1 className="text-4xl sm:text-5xl lg:text-7xl font-black text-white mb-6 leading-tight fade-in-up" style={{ animationDelay: '0.1s' }}>
          اكتشف أفضل
          <br />
          <span className="gradient-text">المنتجات الرقمية</span>
          <br />
          في مكان واحد
        </h1>

        {/* Subtitle */}
        <p className="text-gray-300 text-lg sm:text-xl max-w-2xl mx-auto mb-10 leading-relaxed fade-in-up" style={{ animationDelay: '0.2s' }}>
          قوالب احترافية، كورسات تعليمية، برامج متطورة، وأدوات إبداعية —
          كل ما تحتاجه لتنمية مشروعك الرقمي بأسعار لا تُقارن
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 mb-16 fade-in-up" style={{ animationDelay: '0.3s' }}>
          <button
            onClick={onExplore}
            className="flex items-center gap-2 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white font-bold px-8 py-4 rounded-2xl transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-violet-500/30 pulse-glow"
          >
            تصفح المنتجات
            <ArrowLeft className="w-5 h-5" />
          </button>
          <button className="flex items-center gap-2 glass-card text-white font-bold px-8 py-4 rounded-2xl hover:bg-white/10 transition-all duration-300 hover:scale-105 border border-white/20 hover:border-violet-400/50">
            🎯 شاهد الكورسات
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto fade-in-up" style={{ animationDelay: '0.4s' }}>
          {stats.map((stat, index) => (
            <div key={index} className="glass-card rounded-2xl p-4 flex flex-col items-center gap-2">
              <div className="text-violet-400">{stat.icon}</div>
              <div className="text-white font-black text-2xl">{stat.value}</div>
              <div className="text-gray-400 text-xs">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center pt-2">
          <div className="w-1 h-3 bg-white/60 rounded-full" />
        </div>
      </div>
    </section>
  );
}
