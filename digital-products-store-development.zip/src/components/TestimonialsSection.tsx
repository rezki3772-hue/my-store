import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'أحمد محمد',
    role: 'مطور ويب',
    avatar: '👨‍💻',
    rating: 5,
    comment: 'اشتريت قالب المتجر الإلكتروني وكان أفضل استثمار في مسيرتي. التصميم احترافي جداً والكود نظيف ومنظم. وفّر عليّ أسابيع من العمل!',
    product: 'قالب متجر إلكتروني',
    date: 'منذ أسبوع',
    color: 'from-violet-500 to-purple-600',
  },
  {
    name: 'فاطمة الزهراء',
    role: 'مصممة جرافيك',
    avatar: '👩‍🎨',
    rating: 5,
    comment: 'حزمة الأيقونات رائعة جداً! كميّة كبيرة وجودة عالية. أستخدمها في كل مشاريعي الآن. الدعم الفني سريع الاستجابة ومتعاون.',
    product: 'حزمة أيقونات UI Premium',
    date: 'منذ 3 أيام',
    color: 'from-pink-500 to-rose-600',
  },
  {
    name: 'خالد العمري',
    role: 'رائد أعمال',
    avatar: '👨‍💼',
    rating: 5,
    comment: 'كورس Python غيّر مسيرتي المهنية تماماً. المحتوى عميق ومنظم بشكل ممتاز. أنجزت مشاريع حقيقية خلال الدراسة. أنصح به بشدة!',
    product: 'كورس Python للمبتدئين',
    date: 'منذ 5 أيام',
    color: 'from-green-500 to-emerald-600',
  },
  {
    name: 'سارة أحمد',
    role: 'منتجة محتوى',
    avatar: '👩‍💻',
    rating: 5,
    comment: 'حزمة الموسيقى ذات جودة استديو حقيقية! أستخدمها في كل مقاطع الفيديو الخاصة بي. لا حقوق ملكية وهذا ما كنت أبحث عنه.',
    product: 'حزمة موسيقى للإنتاج',
    date: 'منذ أسبوعين',
    color: 'from-purple-500 to-fuchsia-600',
  },
  {
    name: 'محمد إبراهيم',
    role: 'مطور تطبيقات',
    avatar: '👨‍🔬',
    rating: 5,
    comment: 'اشتريت برنامج تحرير الصور وأنا مبسوط جداً. الفلاتر بالذكاء الاصطناعي مذهلة وتوفر وقتاً كبيراً في العمل.',
    product: 'برنامج تحرير الصور Pro',
    date: 'منذ 4 أيام',
    color: 'from-orange-500 to-amber-600',
  },
  {
    name: 'نور الدين',
    role: 'مسوّق رقمي',
    avatar: '👨‍🚀',
    rating: 5,
    comment: 'كتاب التسويق الرقمي مليء بالمعلومات القيّمة والأمثلة العملية. طبّقت بعض الاستراتيجيات وشهدت نتائج ممتازة في أقل من شهر.',
    product: 'كتاب التسويق الرقمي',
    date: 'منذ أسبوع',
    color: 'from-emerald-500 to-teal-600',
  },
];

export default function TestimonialsSection() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-violet-600/5 rounded-full blur-3xl" />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 glass-card rounded-full px-4 py-2 mb-4 border border-yellow-500/30">
            <span className="text-yellow-400 text-sm font-semibold">💬 آراء عملائنا</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white mb-4">
            ماذا يقول{' '}
            <span className="gradient-text">عملاؤنا</span>
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto">
            انضم إلى آلاف العملاء السعداء الذين غيّرنا مسيرتهم الرقمية
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="glass-card rounded-2xl p-6 card-hover border border-white/10 hover:border-violet-500/30 relative fade-in-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Quote Icon */}
              <div className="absolute top-4 left-4 opacity-10">
                <Quote className="w-10 h-10 text-violet-400" />
              </div>

              {/* Stars */}
              <div className="flex items-center gap-0.5 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-yellow-400" fill="#f59e0b" />
                ))}
              </div>

              {/* Comment */}
              <p className="text-gray-300 text-sm leading-relaxed mb-5">"{testimonial.comment}"</p>

              {/* Product Tag */}
              <div className="mb-4">
                <span className={`inline-block bg-gradient-to-r ${testimonial.color} text-white text-xs px-3 py-1 rounded-full font-semibold`}>
                  {testimonial.product}
                </span>
              </div>

              {/* Author */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${testimonial.color} flex items-center justify-center text-xl`}>
                    {testimonial.avatar}
                  </div>
                  <div>
                    <p className="text-white font-semibold text-sm">{testimonial.name}</p>
                    <p className="text-gray-500 text-xs">{testimonial.role}</p>
                  </div>
                </div>
                <span className="text-gray-600 text-xs">{testimonial.date}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Stats Bar */}
        <div className="mt-16 glass-card rounded-3xl p-8 border border-white/10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { value: '12,000+', label: 'عميل راضٍ' },
              { value: '4.9/5', label: 'متوسط التقييم' },
              { value: '50,000+', label: 'منتج تم بيعه' },
              { value: '98%', label: 'معدل الرضا' },
            ].map((stat, i) => (
              <div key={i}>
                <div className="text-3xl font-black gradient-text mb-1">{stat.value}</div>
                <div className="text-gray-400 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
