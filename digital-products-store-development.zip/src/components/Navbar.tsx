import { useState } from 'react';
import { ShoppingCart, Search, Menu, X, Zap, Bell } from 'lucide-react';
import { CartItem } from '../types';

interface NavbarProps {
  cartItems: CartItem[];
  onCartOpen: () => void;
  onSearch: (query: string) => void;
  searchQuery: string;
}

export default function Navbar({ cartItems, onCartOpen, onSearch, searchQuery }: NavbarProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass-card border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center pulse-glow">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="text-white font-bold text-xl">Digital</span>
              <span className="gradient-text font-bold text-xl">Hub</span>
            </div>
          </div>

          {/* Desktop Nav Links */}
          <div className="hidden md:flex items-center gap-8">
            {['الرئيسية', 'المنتجات', 'الباقات', 'عن المتجر'].map((item) => (
              <a
                key={item}
                href="#"
                className="text-gray-300 hover:text-white transition-colors text-sm font-medium relative group"
              >
                {item}
                <span className="absolute -bottom-1 left-0 right-0 h-0.5 bg-gradient-to-r from-violet-500 to-indigo-500 scale-x-0 group-hover:scale-x-100 transition-transform origin-right" />
              </a>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3">
            {/* Search Bar Desktop */}
            <div className="hidden md:flex items-center gap-2 bg-white/10 rounded-xl px-3 py-2 border border-white/10 hover:border-violet-400/50 transition-colors">
              <Search className="w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="ابحث عن منتج..."
                className="bg-transparent text-white text-sm placeholder-gray-400 outline-none w-40"
                value={searchQuery}
                onChange={(e) => onSearch(e.target.value)}
              />
            </div>

            {/* Notification */}
            <button className="relative w-9 h-9 flex items-center justify-center rounded-xl bg-white/10 hover:bg-white/20 transition-colors">
              <Bell className="w-4 h-4 text-gray-300" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
            </button>

            {/* Cart */}
            <button
              onClick={onCartOpen}
              className="relative w-9 h-9 flex items-center justify-center rounded-xl bg-violet-600 hover:bg-violet-700 transition-colors"
            >
              <ShoppingCart className="w-4 h-4 text-white" />
              {totalItems > 0 && (
                <span className="absolute -top-1.5 -left-1.5 w-5 h-5 bg-red-500 rounded-full text-white text-xs flex items-center justify-center font-bold">
                  {totalItems}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle */}
            <button
              className="md:hidden w-9 h-9 flex items-center justify-center rounded-xl bg-white/10 hover:bg-white/20 transition-colors"
              onClick={() => setMenuOpen(!menuOpen)}
            >
              {menuOpen ? <X className="w-4 h-4 text-white" /> : <Menu className="w-4 h-4 text-white" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {menuOpen && (
          <div className="md:hidden pb-4 space-y-2">
            <div className="flex items-center gap-2 bg-white/10 rounded-xl px-3 py-2 border border-white/10 mb-3">
              <Search className="w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="ابحث عن منتج..."
                className="bg-transparent text-white text-sm placeholder-gray-400 outline-none flex-1"
                value={searchQuery}
                onChange={(e) => onSearch(e.target.value)}
              />
            </div>
            {['الرئيسية', 'المنتجات', 'الباقات', 'عن المتجر'].map((item) => (
              <a
                key={item}
                href="#"
                className="block text-gray-300 hover:text-white transition-colors text-sm font-medium py-2 px-3 rounded-lg hover:bg-white/10"
              >
                {item}
              </a>
            ))}
          </div>
        )}
      </div>
    </nav>
  );
}
