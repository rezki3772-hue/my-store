import { useState } from 'react';
import { Mail, Send, CheckCircle } from 'lucide-react';

export default function NewsletterSection() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
    }
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="relative glass-card rounded-3xl p-10 border border-violet-500/20 overflow-hidden text-center">
          {/* Background Orbs */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-violet-600/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-indigo-600/10 rounded-full blur-3xl" />

          <div className="relative z-10">
            <div className="w-16 h-16 mx-auto bg-gradient-to-br from-violet-600 to-indigo-600 rounded-2xl flex items-center justify-center mb-6 pulse-glow">
              <Mail className="w-8 h-8 text-white" />
            </div>

            <h2 className="text-3xl sm:text-4xl font-black text-white mb-4">
              اشترك في{' '}
              <span className="gradient-text">نشرتنا البريدية</span>
            </h2>
            <p className="text-gray-400 mb-8 max-w-xl mx-auto">
              احصل على أحدث المنتجات والعروض الحصرية مباشرةً في بريدك الإلكتروني.
              وهدية ترحيبية بقيمة 20$ عند الاشتراك الآن! 🎁
            </p>

            {subscribed ? (
              <div className="flex flex-col items-center gap-3 py-4">
                <CheckCircle className="w-12 h-12 text-green-400" />
                <p className="text-green-400 font-bold text-lg">تم الاشتراك بنجاح! 🎉</p>
                <p className="text-gray-400 text-sm">شكراً لك! ستصلك هديتك قريباً</p>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
                <div className="flex-1 flex items-center gap-2 bg-white/10 rounded-2xl px-4 py-3 border border-white/10 hover:border-violet-400/50 transition-colors">
                  <Mail className="w-4 h-4 text-gray-400 flex-shrink-0" />
                  <input
                    type="email"
                    placeholder="أدخل بريدك الإلكتروني..."
                    className="bg-transparent text-white text-sm placeholder-gray-500 outline-none flex-1"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
                <button
                  type="submit"
                  className="flex items-center justify-center gap-2 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white font-bold px-6 py-3 rounded-2xl transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-violet-500/30 whitespace-nowrap"
                >
                  <Send className="w-4 h-4" />
                  اشترك الآن
                </button>
              </form>
            )}

            <p className="text-gray-600 text-xs mt-4">
              🔒 لن نشارك بريدك مع أي جهة أخرى. إلغاء الاشتراك في أي وقت.
            </p>

            {/* Perks */}
            <div className="flex flex-wrap justify-center gap-6 mt-8">
              {['🎁 هدية 20$ للمشتركين الجدد', '🔥 عروض حصرية', '📦 أحدث المنتجات أولاً'].map((perk, i) => (
                <div key={i} className="text-gray-400 text-sm">{perk}</div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
