import { Star, Download, ShoppingCart, Heart, Eye } from 'lucide-react';
import { Product } from '../data/products';
import { useState } from 'react';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
}

export default function ProductCard({ product, onAddToCart, onQuickView }: ProductCardProps) {
  const [wished, setWished] = useState(false);
  const [added, setAdded] = useState(false);

  const handleAddToCart = () => {
    onAddToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : null;

  const badgeStyle: Record<string, string> = {
    'جديد': 'badge-new text-white',
    'الأكثر مبيعاً': 'badge-hot text-white',
    'خصم': 'badge-sale text-white',
  };

  return (
    <div className="group relative glass-card rounded-2xl overflow-hidden card-hover border border-white/10 hover:border-violet-500/50 transition-all duration-300">
      {/* Badge */}
      {product.badge && (
        <div className={`absolute top-3 right-3 z-10 px-3 py-1 rounded-full text-xs font-bold ${badgeStyle[product.badge]}`}>
          {product.badge}
        </div>
      )}

      {/* Discount Badge */}
      {discount && (
        <div className="absolute top-3 left-3 z-10 bg-red-500 text-white px-2 py-1 rounded-lg text-xs font-bold">
          -{discount}%
        </div>
      )}

      {/* Wishlist */}
      <button
        onClick={() => setWished(!wished)}
        className={`absolute top-12 right-3 z-10 w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${
          wished ? 'bg-red-500 text-white' : 'bg-black/40 text-gray-400 opacity-0 group-hover:opacity-100'
        }`}
      >
        <Heart className="w-4 h-4" fill={wished ? 'currentColor' : 'none'} />
      </button>

      {/* Product Icon Area */}
      <div className={`relative h-40 bg-gradient-to-br ${product.color} flex items-center justify-center overflow-hidden`}>
        <div className="absolute inset-0 shimmer" />
        <span className="text-7xl float-animation relative z-10">{product.icon}</span>
        <div className="absolute inset-0 bg-black/10" />

        {/* Quick View Button */}
        <button
          onClick={() => onQuickView(product)}
          className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1 bg-black/50 backdrop-blur-sm text-white text-xs px-3 py-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-black/70 border border-white/20"
        >
          <Eye className="w-3 h-3" />
          عرض سريع
        </button>
      </div>

      {/* Content */}
      <div className="p-5">
        {/* Title */}
        <h3 className="text-white font-bold text-base mb-2 line-clamp-1">{product.name}</h3>
        <p className="text-gray-400 text-xs mb-3 line-clamp-2 leading-relaxed">{product.description}</p>

        {/* Rating */}
        <div className="flex items-center gap-2 mb-3">
          <div className="flex items-center gap-0.5">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className="w-3.5 h-3.5"
                fill={i < Math.floor(product.rating) ? '#f59e0b' : 'none'}
                stroke={i < Math.floor(product.rating) ? '#f59e0b' : '#6b7280'}
              />
            ))}
          </div>
          <span className="text-yellow-400 text-xs font-semibold">{product.rating}</span>
          <span className="text-gray-500 text-xs">({product.reviews.toLocaleString()})</span>
        </div>

        {/* Downloads */}
        <div className="flex items-center gap-1 text-gray-500 text-xs mb-4">
          <Download className="w-3 h-3" />
          <span>{product.downloads.toLocaleString()} تحميل</span>
        </div>

        {/* Features */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {product.features.slice(0, 2).map((feature, i) => (
            <span key={i} className="bg-white/10 text-gray-300 text-xs px-2 py-0.5 rounded-md">
              {feature}
            </span>
          ))}
          {product.features.length > 2 && (
            <span className="bg-white/5 text-gray-500 text-xs px-2 py-0.5 rounded-md">
              +{product.features.length - 2}
            </span>
          )}
        </div>

        {/* Price & CTA */}
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-baseline gap-2">
              <span className="text-white font-black text-xl">${product.price}</span>
              {product.originalPrice && (
                <span className="text-gray-500 text-sm line-through">${product.originalPrice}</span>
              )}
            </div>
          </div>
          <button
            onClick={handleAddToCart}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-bold transition-all duration-300 ${
              added
                ? 'bg-green-500 text-white scale-95'
                : 'bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white hover:scale-105'
            }`}
          >
            {added ? (
              <>✓ تمت الإضافة</>
            ) : (
              <>
                <ShoppingCart className="w-4 h-4" />
                أضف
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
