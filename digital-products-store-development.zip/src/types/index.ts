export interface CartItem {
  id: number;
  name: string;
  price: number;
  icon: string;
  quantity: number;
  color: string;
}
